
import AddChallenge from "../components/getChallenge"
 
export default function addChallenge(){

    return (
        <main>
            <h1>New Challenge</h1>
            <AddChallenge/>
        </main>
    )
}

