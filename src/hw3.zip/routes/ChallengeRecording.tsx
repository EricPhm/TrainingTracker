

import ReturnMain from "../components/ReturnMainBtn"
import ChallengeRecord from "../components/ChallengeRecord"

function ChallengeRecording(){
    return(
        <>
            <ChallengeRecord/>
            <ReturnMain/>
        </>
    )
}

export default ChallengeRecording