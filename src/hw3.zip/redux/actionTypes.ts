
// export const ADD_CHALLENGE = 'ADD_CHALLENGE';

// export interface Segment {
//     name: string;
// }

// export interface challenge{
//     name: string;
//     segment: Segment[];
// }

